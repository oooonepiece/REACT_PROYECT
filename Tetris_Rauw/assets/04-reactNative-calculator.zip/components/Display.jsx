import { StyleSheet, View, ScrollView , Text} from 'react-native';
import { Typography , Colors} from '../styles'


export function Display({operationResult, textOperation}) {
    
    return (
        <View style={styles.container}>
            <ScrollView style={styles.container} contentContainerStyle={styles.scrollView}>
                <Text style={styles.text}>{operationResult}</Text>
                {textOperation ?? false ? <Text style={styles.text}>{textOperation}</Text> : ''}
            </ScrollView>
        </View >
    )
}

const styles = StyleSheet.create({
    container: {
        display: 'flex',
        width: '100%',
        height: '36%',
        marginBottom: 30
    },
    scrollView: {
        flexGrow: 1,
        alignItems: 'flex-end',
        justifyContent: 'flex-end'
    },
    text: {
        fontFamily: Typography.fonts.medium,
        fontSize: Typography.fontSizes.h3,
        color: Colors.colors.white
    }

  });