import {StyleSheet, View} from 'react-native';
import { Colors } from '../styles'
import { ButtonCustom } from './ButtonCustom'

export function Panel({handleSetTextOperation}) {
    
    const panelValues = [
        [
            {value: 'eraser', color: Colors.colors.warning, onPress: () => handleSetTextOperation('')},
            {value: 'percent', color: Colors.colors.warning, onPress: () => handleSetTextOperation('%')},
            {value: 'delete-left', color: Colors.colors.warning, onPress: () => handleSetTextOperation('remove')},
            {value: 'divide', color: Colors.colors.warning, onPress: () => handleSetTextOperation('/')}
        ],
        [
            {value: '7', color: Colors.colors.primary, onPress: () => handleSetTextOperation('7')},
            {value: '8', color: Colors.colors.primary, onPress: () => handleSetTextOperation('8')},
            {value: '9', color: Colors.colors.primary, onPress: () => handleSetTextOperation('9')},
            {value: 'xmark', color: Colors.colors.warning, onPress: () => handleSetTextOperation('*')}
        ],
        [
            {value: '4', color: Colors.colors.primary, onPress: () => handleSetTextOperation('4')},
            {value: '5', color: Colors.colors.primary, onPress: () => handleSetTextOperation('5')},
            {value: '6', color: Colors.colors.primary, onPress: () => handleSetTextOperation('6')},
            {value: 'minus', color: Colors.colors.warning, onPress: () => handleSetTextOperation('-')}
        ],
        [
            {value: '1', color: Colors.colors.primary, onPress: () => handleSetTextOperation('1')},
            {value: '2', color: Colors.colors.primary, onPress: () => handleSetTextOperation('2')},
            {value: '3', color: Colors.colors.primary, onPress: () => handleSetTextOperation('3')},
            {value: 'plus', color: Colors.colors.warning, onPress: () => handleSetTextOperation('+')}
        ],
        [
            {value: 'creative-commons-zero', color: Colors.colors.primary, onPress: () => handleSetTextOperation('00')},
            {value: '0', color: Colors.colors.primary, onPress: () => handleSetTextOperation('0')},
            {value: 'circle-dot', color: Colors.colors.primary, onPress: () => handleSetTextOperation('.')},
            {value: 'equals', color: Colors.colors.warning, onPress: () => handleSetTextOperation('=')}
        ]    
    ]

    return (
        <View style={styles.container}>

            {panelValues.map( (row) => {
                return (
                    <View key={row[0].value} style={styles.row}>
                        {row.map ((elem) => {
                            return (
                                <ButtonCustom key={elem.value} color={elem.color} handleSetTextOperation={elem.onPress}>{elem.value}</ButtonCustom>
                            )
                        })}
                    </View>
                )
            })}

        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        display: 'flex',
        width: '100%',
        height: '100%',
        rowGap: 20,
    },
    row: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '100%',
    }


  });