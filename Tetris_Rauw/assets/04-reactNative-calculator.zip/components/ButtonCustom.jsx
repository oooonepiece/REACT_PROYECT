import { StyleSheet, Text, TouchableOpacity} from 'react-native';
import { FontAwesome6 } from '@expo/vector-icons';
import { Colors , Typography} from '../styles'


export function ButtonCustom ({children, color, handleSetTextOperation}) {
    
    return (
        <TouchableOpacity style={{...styles.button, backgroundColor: color}} onPress={handleSetTextOperation}>
            {<FontAwesome6 name={children} size={20} color="white" /> }
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    text: {
        color: Colors.colors.white,
        fontSize: Typography.fontSizes.h6,
    },
    button: {
        borderRadius : 36,
        height: 72,
        width: 72,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
    }
  });