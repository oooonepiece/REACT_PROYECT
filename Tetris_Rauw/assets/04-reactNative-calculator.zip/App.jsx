import { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { Colors } from './styles'
import { Display } from './components/Display'
import { Panel } from './components/Panel'

import Constants from 'expo-constants';


export default function App() {

  const [textOperation, setTextOperation] = useState('')
  const [operationResult, setOperationResult] = useState(0)

  const concatTextOperation = (elem) => {
    if (elem === '') {
      setTextOperation('')
      setOperationResult(0)
    }
    else if (elem === 'remove') {
      setTextOperation(prevTextOperation => prevTextOperation.slice(0,-1))
    } 
    else if (elem === '=') {
      try{
        result = eval(textOperation)
        result = result %1 ? result.toFixed(2) : result
      }
      catch (err) { 
        result ='Error'
      }
      setOperationResult(result)
      setTextOperation(result.toString())
    } 
    else {
      setTextOperation(prevTextOperation => prevTextOperation.concat(elem))
    }
  }

  return (
      <View style={styles.body}>
          <View style={styles.container}>
              <Display operationResult={operationResult} textOperation={textOperation}></Display>
              <Panel handleSetTextOperation={concatTextOperation}></Panel>
          </View>
      </View>
  );
}

const styles = StyleSheet.create({
  body: {
    width: '100 %',
    height: '100 %',
    backgroundColor: Colors.colors.black
  },
  container: {
    paddingTop : Constants.statusBarHeight,
    padding: Constants.statusBarHeight/1.6,
    width: '100 %',
    height: '100 %',
  }
});
